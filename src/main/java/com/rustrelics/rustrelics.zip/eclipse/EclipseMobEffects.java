package com.rustrelics.eclipse;

import com.rustrelics.stage.StageSavedData;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * Evita que los mobs hostiles se quemen con el sol durante un Eclipse Solar.
 *
 * Barre las entidades cargadas cada 20 ticks SOLO cuando el eclipse esta
 * activo — coste minimo porque el eclipse es raro (es un flag int, ~0
 * overhead en estado normal).
 */
public final class EclipseMobEffects {

    private static final int INTERVAL = 20;

    private EclipseMobEffects() {}

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        MinecraftServer server = event.getServer();
        if (server.getTickCount() % INTERVAL != 0) return;

        // El eclipse es un fenomeno del overworld: solo ahi se queman los mobs
        // con el sol. Iterar Nether/End apagaria su fuego legitimo (lava) y es
        // trabajo desperdiciado.
        ServerLevel overworld = server.overworld();
        if (StageSavedData.get(overworld).getEclipseTicks() <= 0) return;

        for (Entity entity : overworld.getEntities().getAll()) {
            if (entity instanceof Mob mob && mob.isOnFire()) {
                mob.clearFire();
            }
        }
    }
}
